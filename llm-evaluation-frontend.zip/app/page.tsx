'use client'

import { useState, useEffect } from 'react'
import { QueryInput } from './components/QueryInput'
import { ResultsDisplay } from './components/ResultsDisplay'
import { ThemeProvider } from './components/ThemeProvider'
import { ThemeToggle } from './components/ThemeToggle'
import { motion } from 'framer-motion'

export default function Home() {
  const [results, setResults] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [aggregateScores, setAggregateScores] = useState({})

  useEffect(() => {
    fetchAggregateScores()
  }, [])

  const fetchAggregateScores = async () => {
    try {
      const response = await fetch('http://localhost:3000/llm/aggregateScores')
      const data = await response.json()
      setAggregateScores(data.aggregateScores)
    } catch (error) {
      console.error('Error fetching aggregate scores:', error)
    }
  }

  const handleQuerySubmit = async (query: string) => {
    setIsLoading(true)
    setResults(null)
    try {
      const response = await fetch('http://localhost:3000/experiment/runOnePrompt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userPrompt: query }),
      })
      const data = await response.json()
      setResults(data)
      fetchAggregateScores() // Refresh aggregate scores after new results
    } catch (error) {
      console.error('Error submitting query:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <main className="container mx-auto p-4 min-h-screen flex flex-col">
        <nav className="flex justify-between items-center mb-8">
          <motion.h1
            className="text-3xl font-bold"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            LLM Evaluation Project
          </motion.h1>
          <ThemeToggle />
        </nav>
        <QueryInput onSubmit={handleQuerySubmit} isLoading={isLoading} />
        {isLoading && (
          <motion.div
            className="flex justify-center items-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>
        )}
        {results && <ResultsDisplay results={results} aggregateScores={aggregateScores} />}
      </main>
    </ThemeProvider>
  )
}

